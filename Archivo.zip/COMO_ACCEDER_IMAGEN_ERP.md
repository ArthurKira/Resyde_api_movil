# 📸 Cómo Acceder a la Imagen del Medidor desde el ERP Laravel

## 📋 Información Importante

### ¿Qué se guarda en la Base de Datos?

En la tabla `invoices`, el campo `medidor_image` contiene una **ruta relativa**:

```
medidores/agua/2025/Setiembre/invoice_2771_1763940700.jpg
```

### ¿Dónde está la imagen físicamente?

La imagen se guarda en el storage del ERP:

```
/home/uclubnet/resyde_erp/storage/app/public/medidores/agua/2025/Setiembre/invoice_2771_1763940700.jpg
```

### ¿Cuál es la URL pública?

```
https://erp.uclub.net.pe/storage/medidores/agua/2025/Setiembre/invoice_2771_1763940700.jpg
```

---

## 🔧 Métodos para Acceder desde el ERP Laravel

### Método 1: Usar `asset()` Helper (Recomendado) ✅

**En tu Blade o Controller del ERP:**

```php
// Obtener el recibo
$invoice = DB::table('invoices')->where('id', $invoiceId)->first();

// Construir la URL de la imagen
if ($invoice->medidor_image) {
    $imagenUrl = asset('storage/' . $invoice->medidor_image);
    // Resultado: https://erp.uclub.net.pe/storage/medidores/agua/2025/Setiembre/invoice_2771_1763940700.jpg
}
```

**En Blade:**
```blade
@if($invoice->medidor_image)
    <img src="{{ asset('storage/' . $invoice->medidor_image) }}" 
         alt="Medidor de Agua" 
         class="img-fluid">
@else
    <p>No hay imagen disponible</p>
@endif
```

---

### Método 2: Usar `Storage::url()` (Si tienes acceso al Storage)

**En tu Controller del ERP:**

```php
use Illuminate\Support\Facades\Storage;

// Obtener el recibo
$invoice = DB::table('invoices')->where('id', $invoiceId)->first();

// Generar URL usando Storage
if ($invoice->medidor_image) {
    $imagenUrl = Storage::url($invoice->medidor_image);
    // Resultado: https://erp.uclub.net.pe/storage/medidores/agua/2025/Setiembre/invoice_2771_1763940700.jpg
}
```

**Nota:** Esto requiere que el enlace simbólico `storage` esté creado en el ERP.

---

### Método 3: Construir la URL Manualmente

**Si prefieres construir la URL manualmente:**

```php
// Obtener el recibo
$invoice = DB::table('invoices')->where('id', $invoiceId)->first();

// Construir URL manualmente
if ($invoice->medidor_image) {
    $baseUrl = config('app.url'); // https://erp.uclub.net.pe
    $imagenUrl = $baseUrl . '/storage/' . $invoice->medidor_image;
    // Resultado: https://erp.uclub.net.pe/storage/medidores/agua/2025/Setiembre/invoice_2771_1763940700.jpg
}
```

---

### Método 4: Usar Helper Personalizado (Recomendado para Reutilización)

**Crear un Helper en el ERP:**

**Archivo: `app/Helpers/InvoiceHelper.php`**

```php
<?php

namespace App\Helpers;

class InvoiceHelper
{
    /**
     * Obtener la URL completa de la imagen del medidor
     *
     * @param string|null $medidorImage Ruta relativa del medidor_image
     * @return string|null URL completa o null si no hay imagen
     */
    public static function getMedidorImageUrl($medidorImage)
    {
        if (empty($medidorImage)) {
            return null;
        }

        return asset('storage/' . $medidorImage);
    }

    /**
     * Verificar si existe la imagen físicamente
     *
     * @param string|null $medidorImage Ruta relativa del medidor_image
     * @return bool
     */
    public static function medidorImageExists($medidorImage)
    {
        if (empty($medidorImage)) {
            return false;
        }

        $path = storage_path('app/public/' . $medidorImage);
        return file_exists($path);
    }
}
```

**Registrar el Helper en `composer.json`:**

```json
{
    "autoload": {
        "files": [
            "app/Helpers/InvoiceHelper.php"
        ]
    }
}
```

Luego ejecutar:
```bash
composer dump-autoload
```

**Uso del Helper:**

```php
use App\Helpers\InvoiceHelper;

$invoice = DB::table('invoices')->where('id', $invoiceId)->first();

// Obtener URL
$imagenUrl = InvoiceHelper::getMedidorImageUrl($invoice->medidor_image);

// Verificar si existe
if (InvoiceHelper::medidorImageExists($invoice->medidor_image)) {
    // Mostrar imagen
}
```

---

## 📝 Ejemplo Completo en un Controller del ERP

```php
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class InvoiceController extends Controller
{
    public function show($id)
    {
        $invoice = DB::table('invoices')
            ->where('id', $id)
            ->first();

        if (!$invoice) {
            abort(404);
        }

        // Construir URL de la imagen del medidor
        $medidorImageUrl = null;
        if ($invoice->medidor_image) {
            $medidorImageUrl = asset('storage/' . $invoice->medidor_image);
        }

        return view('invoices.show', [
            'invoice' => $invoice,
            'medidorImageUrl' => $medidorImageUrl,
        ]);
    }
}
```

**En la Vista Blade (`resources/views/invoices/show.blade.php`):**

```blade
<div class="invoice-details">
    <h2>Recibo #{{ $invoice->id }}</h2>
    
    <!-- Mostrar imagen del medidor si existe -->
    @if($medidorImageUrl)
        <div class="medidor-image">
            <h3>Imagen del Medidor</h3>
            <img src="{{ $medidorImageUrl }}" 
                 alt="Medidor de Agua - Recibo #{{ $invoice->id }}"
                 class="img-fluid rounded"
                 style="max-width: 500px;">
        </div>
    @else
        <p class="text-muted">No hay imagen del medidor disponible</p>
    @endif
    
    <!-- Otros datos del recibo -->
    <div class="invoice-data">
        <p><strong>Lectura Actual:</strong> {{ $invoice->lectura_actual ?? 'N/A' }}</p>
        <p><strong>Lectura Pasada:</strong> {{ $invoice->lectura_pasada ?? 'N/A' }}</p>
        <p><strong>Diferencia:</strong> {{ $invoice->diferencia ?? 'N/A' }}</p>
    </div>
</div>
```

---

## ✅ Verificar que el Enlace Simbólico Existe

**IMPORTANTE:** Asegúrate de que el enlace simbólico `storage` esté creado en el ERP:

```bash
# Desde la raíz del ERP
php artisan storage:link
```

Esto crea el enlace: `public/storage` → `storage/app/public`

**Verificar manualmente:**

```bash
ls -la public/storage
# Debe mostrar: public/storage -> ../storage/app/public
```

---

## 🔍 Verificar que la Imagen Existe Físicamente

**En el Controller del ERP, puedes verificar:**

```php
use Illuminate\Support\Facades\Storage;

$invoice = DB::table('invoices')->where('id', $invoiceId)->first();

if ($invoice->medidor_image) {
    $path = storage_path('app/public/' . $invoice->medidor_image);
    
    if (file_exists($path)) {
        // La imagen existe
        $imagenUrl = asset('storage/' . $invoice->medidor_image);
    } else {
        // La imagen no existe físicamente
        $imagenUrl = null;
    }
}
```

---

## 📋 Resumen de Rutas

| Concepto | Valor |
|----------|-------|
| **Campo en BD** | `medidor_image` |
| **Valor en BD** | `medidores/agua/2025/Setiembre/invoice_2771_1763940700.jpg` |
| **Ruta Física** | `/home/uclubnet/resyde_erp/storage/app/public/medidores/agua/2025/Setiembre/invoice_2771_1763940700.jpg` |
| **URL Pública** | `https://erp.uclub.net.pe/storage/medidores/agua/2025/Setiembre/invoice_2771_1763940700.jpg` |
| **Helper Laravel** | `asset('storage/' . $invoice->medidor_image)` |

---

## 🚨 Solución de Problemas

### Problema: La imagen no se muestra (404)

**Causa 1:** El enlace simbólico no existe
```bash
# Solución: Crear el enlace
php artisan storage:link
```

**Causa 2:** La ruta en la BD está incorrecta
```php
// Verificar el valor en la BD
$invoice = DB::table('invoices')->where('id', $id)->first();
dd($invoice->medidor_image); // Ver qué contiene
```

**Causa 3:** Permisos incorrectos
```bash
# Verificar permisos
chmod -R 755 storage/app/public
chown -R www-data:www-data storage/app/public
```

### Problema: La URL se genera incorrectamente

**Verificar `APP_URL` en `.env` del ERP:**
```env
APP_URL=https://erp.uclub.net.pe
```

---

## 💡 Recomendación Final

**Usa el Método 1 (`asset()` helper)** porque:
- ✅ Es el más simple
- ✅ Funciona automáticamente con `APP_URL`
- ✅ No requiere configuración adicional
- ✅ Es la forma estándar en Laravel

```php
$imagenUrl = asset('storage/' . $invoice->medidor_image);
```

