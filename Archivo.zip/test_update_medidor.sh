#!/bin/bash

# Script de prueba para el endpoint updateMedidor
# Uso: ./test_update_medidor.sh

# Colores para output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${YELLOW}🧪 Prueba del Endpoint updateMedidor${NC}\n"

# Variables (ajusta según tu configuración)
BASE_URL="http://localhost:8000"
TOKEN=""  # Pega tu token aquí después de hacer login
INVOICE_ID=1  # ID del recibo a actualizar
IMAGE_PATH=""  # Ruta a tu imagen de prueba
LECTURA="1250.50"

# Verificar que el servidor esté corriendo
echo -e "${YELLOW}1. Verificando servidor...${NC}"
if curl -s "$BASE_URL" > /dev/null; then
    echo -e "${GREEN}✅ Servidor corriendo${NC}\n"
else
    echo -e "${RED}❌ Servidor no responde. ¿Está corriendo? (php artisan serve)${NC}\n"
    exit 1
fi

# Si no hay token, intentar hacer login
if [ -z "$TOKEN" ]; then
    echo -e "${YELLOW}2. No hay token. Necesitas hacer login primero.${NC}"
    echo -e "Ejecuta esto primero:"
    echo -e "${GREEN}curl -X POST \"$BASE_URL/api/auth/login\" \\"
    echo -e "  -H \"Content-Type: application/json\" \\"
    echo -e "  -d '{\"email\":\"tu@email.com\",\"password\":\"tu_password\"}'${NC}\n"
    echo -e "Luego copia el token y edita este script para agregarlo.\n"
    exit 1
fi

# Verificar que existe la imagen
if [ -z "$IMAGE_PATH" ] || [ ! -f "$IMAGE_PATH" ]; then
    echo -e "${YELLOW}3. No hay imagen especificada o no existe.${NC}"
    echo -e "Edita este script y agrega la ruta a tu imagen en IMAGE_PATH\n"
    exit 1
fi

echo -e "${YELLOW}2. Probando endpoint updateMedidor...${NC}\n"

# Hacer la petición
RESPONSE=$(curl -s -w "\n%{http_code}" -X POST "$BASE_URL/api/recibos/$INVOICE_ID/medidor" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Accept: application/json" \
  -F "imagen=@$IMAGE_PATH" \
  -F "lectura_actual=$LECTURA")

# Separar respuesta y código HTTP
HTTP_CODE=$(echo "$RESPONSE" | tail -n1)
BODY=$(echo "$RESPONSE" | sed '$d')

echo -e "${YELLOW}HTTP Status: $HTTP_CODE${NC}\n"

if [ "$HTTP_CODE" -eq 200 ]; then
    echo -e "${GREEN}✅ Éxito!${NC}\n"
    echo "$BODY" | python3 -m json.tool 2>/dev/null || echo "$BODY"
else
    echo -e "${RED}❌ Error${NC}\n"
    echo "$BODY" | python3 -m json.tool 2>/dev/null || echo "$BODY"
fi

