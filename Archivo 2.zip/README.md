# Resyde_api_movil
